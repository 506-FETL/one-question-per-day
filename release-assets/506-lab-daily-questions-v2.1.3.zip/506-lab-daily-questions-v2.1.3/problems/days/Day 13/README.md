## add

实现一个 add 要求能达到一下效果：

```js
const value = add[100] + 1
console.log(value) // 101
console.log(value[200][300] + 100) // 701
console.log(add[100][200][300] - 300) // 300
```
