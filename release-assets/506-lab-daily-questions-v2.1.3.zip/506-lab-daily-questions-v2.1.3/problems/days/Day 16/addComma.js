/**
 * @param {number} num
 * @return {string}
 */
export default function addComma(num) {}
