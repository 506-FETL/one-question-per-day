/**
 * @param {any} input
 * @returns {true | false}
 */
export default function myExpect(input) {}
