export function commitNestedComponent(root, onCommitUnmount) {
  //TODO 对每一个node(包含root)执行onCommitUnmount(node)
}
