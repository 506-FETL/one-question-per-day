/**
 * @param v 传入的值
 */
const sum = (v = 0) => {}

export default sum
