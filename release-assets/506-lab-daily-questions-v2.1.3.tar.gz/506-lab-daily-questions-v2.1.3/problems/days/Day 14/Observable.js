class Observable {
  constructor(setup) {}

  subscribe(subscriber) {}
}

export default Observable
