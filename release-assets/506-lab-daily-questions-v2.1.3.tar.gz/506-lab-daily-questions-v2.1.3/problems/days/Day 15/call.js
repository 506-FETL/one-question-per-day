Function.prototype.mycall = function (thisArg, ...args) {}
