export function effect(fn) {}
export function reactive(obj) {}
