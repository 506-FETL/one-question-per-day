import type { EffectFunc, ReactiveFunc } from './types'

export const effect: EffectFunc = (fn) => {}

export const reactive: ReactiveFunc = (obj) => {
  return obj
}
