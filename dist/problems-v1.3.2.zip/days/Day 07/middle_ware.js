export default class Middleware {}
