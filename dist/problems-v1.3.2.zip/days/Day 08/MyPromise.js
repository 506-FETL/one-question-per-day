/*global process */

export default class MyPromise {
  constructor(executor) {}
}
